package com.tcs.ilp.tsi.util;

public class Constants {
	
	public static final String DRIVER = "oracle.jdbc.driver.OracleDriver";
	public static final String CONNECTIONURL = "jdbc:oracle:thin:@172.24.137.30:1521:ora10g";
	public static final String DBUSERNAME = "e772540";
	public static final String DBPASSWORD = "xddHhtPls";
}
