package com.tcs.ilp.tsi.vo;

public class PackageVO {
	int package_id;
	String offers;
	float amount;
	public int getPackage_id() {
		return package_id;
	}
	public void setPackage_id(int packageId) {
		package_id = packageId;
	}
	public String getOffers() {
		return offers;
	}
	public void setOffers(String offers) {
		this.offers = offers;
	}
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	
}
	
