package com.tcs.ilp.tsi.vo;

public class RetailerVO {
	public int retailerID;
	public String retailerName;
	public String location;
	public String  licenseNumber;
	public String userID;
	public int getRetailerID() {
		return retailerID;
	}
	public void setRetailerID(int retailerID) {
		this.retailerID = retailerID;
	}
	public String getRetailerName() {
		return retailerName;
	}
	public void setRetailerName(String retailerName) {
		this.retailerName = retailerName;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getLicenseNumber() {
		return licenseNumber;
	}
	public void setLicenseNumber(String licenseNumber) {
		this.licenseNumber = licenseNumber;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
}
