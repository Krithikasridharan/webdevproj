function toggle_visibility_model(id1, id2, id3, id4, id5) {
	
	
	var box1sub1 = document.getElementById(id1);
	var box1sub2 = document.getElementById(id2);
	var box1sub3 = document.getElementById(id3);
	var box1sub4 = document.getElementById(id4);
	var box1sub5 = document.getElementById(id5);
	
	if(box1sub1.style.display == 'block')
	{
		box1sub1.style.display = 'none';
	}
    else
	{
		box1sub1.style.display = 'block';
	}
	
	
	if(box1sub2.style.display == 'block')
	{
		box1sub2.style.display = 'none';
	}
    else
	{
		box1sub2.style.display = 'block';
	}
	
	if(box1sub3.style.display == 'block')
	{
		box1sub3.style.display = 'none';
	}
    else
	{
		box1sub3.style.display = 'block';
	}
	
	if(box1sub4.style.display == 'block')
	{
		box1sub4.style.display = 'none';
	}
    else
	{
		box1sub4.style.display = 'block';
	}
	
	if(box1sub5.style.display == 'block')
	{
		box1sub5.style.display = 'none';
	}
    else
	{
		box1sub5.style.display = 'block';
	}
}